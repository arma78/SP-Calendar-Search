﻿Imports System
Imports System.ComponentModel
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.WebControls
Imports System.Web.UI
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls.DateTimeControl
Imports Microsoft.SharePoint.WebControls
Imports Microsoft.SharePoint.Utilities
Imports System.Threading
Imports System.Text.RegularExpressions
Imports System.Web
Imports System.Text
Imports System.IO
Imports Microsoft.Web.Hosting.Administration
Imports System.Net.Mail
Imports System.Security.Cryptography.X509Certificates
Imports System.Net.Security
Imports System.Net
Imports System.Globalization


<ToolboxItem(False)> _
Partial Public Class NC_Content_WP
    Inherits WebPart
    Public Sub New()
    End Sub
    Protected Overrides Sub CreateChildControls()
        MyBase.CreateChildControls()
    End Sub
    Protected SecuritySpGroup As String = "NewsClippingsAdmin"
    Protected _CorpComSpGroup As String = "CorporateCommunicationSPGroup"
    Protected EmailError As String = "netfeedback@mpi.mb.ca"
    Protected _SmptServerName As String = "smtp.mpic.mb.ca"
    Protected _urlPath As String
    <Personalizable(PersonalizationScope.[Shared]), _
     WebBrowsable(True),
     WebDisplayName("Site URL: "), _
     WebDescription("Type URL place where you want to display this webpart.")> _
    Public Property UrlPath() As String
        Get
            Return _urlPath
        End Get
        Set(ByVal value As String)
            _urlPath = value
        End Set
    End Property
    <Personalizable(PersonalizationScope.[Shared]), _
    WebBrowsable(True),
    WebDisplayName("Type SP Security Group Name: "), _
    WebDescription("Set SP Admin Group.")> _
    Public Property SecSpGroup() As String
        Get
            Return SecuritySpGroup
        End Get
        Set(ByVal value As String)
            SecuritySpGroup = value
        End Set
    End Property
    <Personalizable(PersonalizationScope.[Shared]), _
    WebBrowsable(True),
    WebDisplayName("Type SP Corporate Communication Group Name: "), _
    WebDescription("Set SP Corporate Communication Group.")> _
    Public Property CorpComSpGroup() As String
        Get
            Return _CorpComSpGroup
        End Get
        Set(ByVal value As String)
            _CorpComSpGroup = value
        End Set
    End Property
    <Personalizable(PersonalizationScope.[Shared]), _
   WebBrowsable(True),
   WebDisplayName("Type E-mail to send error log: "), _
   WebDescription("All errors in this app. will be logged and sent to the following e-mail address")> _
    Public Property ErrorLog() As String
        Get
            Return EmailError
        End Get
        Set(ByVal value As String)
            EmailError = value
        End Set
    End Property
    <Personalizable(PersonalizationScope.[Shared]), _
  WebBrowsable(True),
  WebDisplayName("Type SMTP Server Name: "), _
  WebDescription("SMTP Server Name")> _
    Public Property SmptServerName() As String
        Get
            Return _SmptServerName
        End Get
        Set(ByVal value As String)
            _SmptServerName = value
        End Set
    End Property

    Protected Overrides Sub OnInit(ByVal e As System.EventArgs)
        MyBase.OnInit(e)
        InitializeControl()
        LoadNavigation()
    End Sub
    Private Shared _seldate As DateTime

    Public Property SelectedDate() As DateTime
        Get
            Return _seldate
        End Get
        Private Set(ByVal value As DateTime)
            _seldate = value
        End Set
    End Property
    Private Shared _startDate As DateTime
    Public Property StartDate() As DateTime
        Get
            Return _startDate
        End Get
        Private Set(ByVal value As DateTime)
            _startDate = value
        End Set
    End Property
    Private Shared _endDate As DateTime
    Public Property EndDate() As DateTime
        Get
            Return _endDate
        End Get
        Private Set(ByVal value As DateTime)
            _endDate = value
        End Set
    End Property
    Private Shared _htmlTables As String
    Public Property htmlTables As String
        Get
            Return _htmlTables
        End Get
        Private Set(ByVal value As String)
            _htmlTables = value
        End Set
    End Property
    Private Shared _htmlTitles As String
    Public Property htmlTitles As String
        Get
            Return _htmlTitles
        End Get
        Private Set(ByVal value As String)
            _htmlTitles = value
        End Set
    End Property
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Hide Admin Section from Users
        If (IsUserAuthorized(SecuritySpGroup) = False) Then
            AddNewsClipping.Visible = False
            UnpublishedItems.Visible = False
            AddArticleRow.Visible = False
            Preview.Visible = False
            AddClipping.Visible = False
            NC_HtmlGeneration.Visible = False
            MultiNewsRepeater.Visible = False
            DateTimeControl1.Visible = False
            DateTimeControl2.Visible = False
            ssdlbl.Visible = False
            sedlbl.Visible = False
            Button1.Visible = False
        End If
        'Hide control if user is not member of the CorporateCommunicationSPGroup
        If (IsUserAuthorized(_CorpComSpGroup) = False) Then
            LblEmailSubscriber.Visible = False
            CB_EmailSubscriber.Visible = False
            CB_EmailSubscriber.Enabled = False
        End If

        If _urlPath <> Nothing Then
            If Not Page.IsPostBack Then

                Calendar1.TodaysDate = Date.Today
                Calendar1.SelectedDate = Calendar1.TodaysDate
                _seldate = Calendar1.SelectedDate
                getNews()
                If Repeater1.Items.Count = 0 Then
                    lblDate.Text = "No News Articles published on Today's Date!"
                Else
                    lblDate.Text = Repeater1.Items.Count.ToString() + " - News Articles Published on Today's Date"
                End If
                SetInitialRow()
                DistributionList()
            End If
        End If
    End Sub
    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
        lblDate.Text = ""
        _startDate = Nothing
        _endDate = Nothing
        UnpublishedItems.Checked = False
        DateTimeControl1.SelectedDate = Nothing
        DateTimeControl2.SelectedDate = Nothing
        DateTimeControl1.ClearSelection()
        DateTimeControl2.ClearSelection()
        _seldate = Calendar1.SelectedDate
        lblDate.Text = "News Articles published on: " + _seldate.ToShortDateString().ToString()
        getNews()
    End Sub
    Protected Sub DateTimeControlCT_DateChanged(sender As Object, e As EventArgs) Handles DateTimeControlCT.DateChanged
        ' Dim lblSourcedate As TextBox = CType(FindControl("lblSourcedate"), TextBox)
        'lblSourcedate.Text = DateTimeControlCT.SelectedDate.ToString("MMM/dd/yyyy")
    End Sub
    Protected Sub Repeater1_ItemDataBound(ByVal sender As Object, ByVal e As RepeaterItemEventArgs) Handles Repeater1.ItemDataBound
        Dim ri As RepeaterItem = e.Item
        If ((ri.ItemType = ListItemType.Item) _
                    OrElse (ri.ItemType = ListItemType.AlternatingItem)) Then
            Dim btn As ImageButton = CType(ri.FindControl("oDeleteIcon"), ImageButton)
            Dim btn1 As ImageButton = CType(ri.FindControl("oEditIcon"), ImageButton)
            Dim btn2 As ImageButton = CType(ri.FindControl("oPublishIcon"), ImageButton)
            Dim btn3 As ImageButton = CType(ri.FindControl("oeMailIcon"), ImageButton)
            Dim lbl1 As Label = CType(ri.FindControl("lblId"), Label)
            Dim Chbx As CheckBox = CType(ri.FindControl("oEmailChecker"), CheckBox)


            If (Not (btn) Is Nothing) Or (Not (btn1) Is Nothing) Or (Not (btn2) Is Nothing) Or (Not (lbl1) Is Nothing) Then
                If (IsUserAuthorized(SecuritySpGroup) = False) Then
                    btn.Visible = False
                    btn1.Visible = False
                    btn2.Visible = False
                    btn3.Visible = False
                    Chbx.Visible = False
                    lbl1.Visible = False

                End If
                'Hide publishing icon after item has been published
                Try
                    SPSecurity.RunWithElevatedPrivileges(Sub()
                                                             Dim web As SPWeb = Nothing
                                                             Using Site As SPSite = New SPSite(_urlPath)
                                                                 web = Site.OpenWeb()
                                                                 Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                                 Dim idfromlbl As Integer = Convert.ToInt32(lbl1.Text)
                                                                 Dim itemToPublish As SPListItem = lstDocs.GetItemById(idfromlbl)
                                                                 If itemToPublish("PublishingChecker") = True Then
                                                                     btn2.Visible = False
                                                                     lbl1.Visible = False
                                                                     If itemToPublish("MailSent") = True Then
                                                                         btn3.ImageUrl = "~/Style Library/NewsClippingsImages/NewsClippingsImages/AppIcon.png"
                                                                         btn3.ToolTip = "News Clippings Page has been E-mailed to Users"
                                                                         btn3.Enabled = False
                                                                     End If
                                                                 Else
                                                                     btn3.Visible = False
                                                                 End If
                                                             End Using
                                                         End Sub)
                Catch ex As Exception
                    labelError.Text = "Published item icon error " & vbCrLf & ex.Message
                End Try
            End If
        End If
    End Sub
    Private Sub Repeater1_ItemCommand(sender As Object, e As RepeaterCommandEventArgs) Handles Repeater1.ItemCommand
        labelError.Text = ""
        If (IsUserAuthorized(SecuritySpGroup) = True) Then
            If (e.CommandName = "Delete") Then
                Dim idNews As Integer = e.CommandArgument
                Try
                    SPSecurity.RunWithElevatedPrivileges(Sub()
                                                             Dim web As SPWeb = Nothing
                                                             Using Site As SPSite = New SPSite(_urlPath)
                                                                 web = Site.OpenWeb()
                                                                 Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                                 web.AllowUnsafeUpdates = True
                                                                 Dim itemToDelete As SPListItem = lstDocs.GetItemById(idNews)
                                                                 itemToDelete.Delete()
                                                                 web.AllowUnsafeUpdates = False
                                                             End Using
                                                         End Sub)
                Catch ex As Exception
                    'labelError.Text = "Can not Delete News Page" & vbCrLf & ex.Message
                    SendErrorToNetFeedback(ex)
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not Delete this News Article Page!');", True)
                End Try
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Success, Message Info", "javascript:success('Sucessfully Deleted this News Clippings Article Page');", True)
                getNews()
            End If
            If (e.CommandName = "Edit") Then
                Dim idNews As Integer = e.CommandArgument
                Try
                    SPSecurity.RunWithElevatedPrivileges(Sub()
                                                             Dim newUrl As String
                                                             Dim web As SPWeb = Nothing
                                                             Using Site As SPSite = New SPSite(_urlPath)
                                                                 web = Site.OpenWeb()
                                                                 Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                                 Dim itemToPublish As SPListItem = lstDocs.GetItemById(idNews)
                                                                 newUrl = web.ServerRelativeUrl + "Lists/News%20Articles/EditForm.aspx?ID=" + idNews.ToString() + "&Source=" + _urlPath + "/Pages/testt.aspx"
                                                                 HttpContext.Current.Response.Redirect(newUrl)
                                                             End Using
                                                         End Sub)
                Catch ex As Exception
                    'labelError.Text = "Can not Check-Out News Page to Edit" & vbCrLf & ex.Message
                    'SendErrorToNetFeedback(ex)
                    'ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not Edit this News Article Page!');", True)
                End Try
            End If
            If (e.CommandName = "Publish") Then
                Dim idNews As Integer = e.CommandArgument
                Try
                    SPSecurity.RunWithElevatedPrivileges(Sub()
                                                             Using Site As SPSite = New SPSite(_urlPath)
                                                                 Using web As SPWeb = Site.OpenWeb()
                                                                     Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                                     Dim CurrrentUser As String = (SPContext.Current.Web.CurrentUser).ToString()
                                                                     web.AllowUnsafeUpdates = True
                                                                     Dim itemToPublish As SPListItem = lstDocs.GetItemById(idNews)
                                                                     itemToPublish("PublishingChecker") = 1
                                                                     itemToPublish("ArticlePublishingDate") = Today
                                                                     itemToPublish.Update()
                                                                     web.AllowUnsafeUpdates = False
                                                                 End Using
                                                             End Using
                                                         End Sub)
                Catch ex As Exception
                    'labelError.Text = "Can not Publish or Check-In News Page" & vbCrLf & ex.Message
                    SendErrorToNetFeedback(ex)
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not Publish this News Article Page!');", True)
                End Try
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Success, Message Info", "javascript:success('Sucessfully Published this News Clippings Article Page');", True)
                getNews()
            End If
            If (e.CommandName = "Sendm") Then
                Dim idNews As Integer = e.CommandArgument
                Try
                    SPSecurity.RunWithElevatedPrivileges(Sub()
                                                             Using Site As SPSite = New SPSite(_urlPath)
                                                                 Using web As SPWeb = Site.OpenWeb()
                                                                     'Send E-mail to people from distribution list
                                                                     Dim userstomailto As String = ""
                                                                     Dim NCDList As SPList = SPContext.Current.Web.Lists.TryGetList("NC Distribution List")
                                                                     Dim ls As SPListItemCollection = NCDList.Items
                                                                     Dim count As Integer = ls.List.Items.Count
                                                                     If count > 0 Then
                                                                         Dim DLitem As SPListItem
                                                                         For Each DLitem In ls
                                                                             userstomailto += DLitem("Title").ToString() + ","
                                                                         Next DLitem
                                                                     End If

                                                                     'Dim listoMail As New List(Of String)
                                                                     Dim spGroup As SPGroup = web.Groups.GetByName(_CorpComSpGroup)
                                                                     Dim spUser As SPUser
                                                                     'Dim spUser1 As SPUser
                                                                     For Each spUser In spGroup.Users
                                                                         If spUser.Email <> Nothing Then
                                                                             userstomailto += spUser.Email.ToString() + ","
                                                                         End If
                                                                     Next spUser
                                                                     userstomailto = userstomailto.Remove(userstomailto.Length - 1)
                                                                     Dim Smtp_Server As New SmtpClient
                                                                     Dim e_mail As New MailMessage()
                                                                     Smtp_Server.UseDefaultCredentials = True
                                                                     'Smtp_Server.Credentials = New Net.NetworkCredential("", "")
                                                                     Smtp_Server.Port = 25
                                                                     Smtp_Server.EnableSsl = True
                                                                     Smtp_Server.Host = _SmptServerName
                                                                     e_mail = New MailMessage()
                                                                     e_mail.From = New MailAddress("netfeedback@mpi.mb.ca")
                                                                     e_mail.To.Add(userstomailto)
                                                                     e_mail.Subject = "Todays News Clipping"
                                                                     e_mail.IsBodyHtml = True
                                                                     Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                                     Dim itemToPublish As SPListItem = lstDocs.GetItemById(idNews)
                                                                     Dim getArticle As String = itemToPublish.GetFormattedValue("NewsArticle")

                                                                     Dim strToday As String = itemToPublish("ArticlePublishingDate").ToString()
                                                                     e_mail.Body += "<html>" & vbNewLine
                                                                     e_mail.Body += "<head>" & vbNewLine
                                                                     e_mail.Body += "<title><font face=verdana size=4 color=blue>News Clippings - " & strToday & "</font></title>" & vbNewLine
                                                                     e_mail.Body += "</head>" & vbNewLine & vbNewLine
                                                                     e_mail.Body += "<body class=""textblack"">" & vbNewLine
                                                                     e_mail.Body += "<h2><font face=verdana size=4 color=blue>News Clippings - " & strToday & "</font></h2>" & vbNewLine
                                                                     e_mail.Body += "<p>" & getArticle & "</p>" & vbNewLine
                                                                     e_mail.Body += "<br>"
                                                                     e_mail.Body += "<br>"
                                                                     e_mail.Body += "<a href=""http://kndev-stage/Pages/testt.aspx""><font color=""#9970B1"">Visit our News Clippings Archive</font></a>"
                                                                     e_mail.Body += "</body>" & vbNewLine
                                                                     e_mail.Body += "</html>"
                                                                     ServicePointManager.ServerCertificateValidationCallback = New System.Net.Security.RemoteCertificateValidationCallback(AddressOf customCertValidation)
                                                                     Smtp_Server.Send(e_mail)
                                                                     web.AllowUnsafeUpdates = True
                                                                     itemToPublish("MailSent") = 1
                                                                     itemToPublish.Update()
                                                                     web.AllowUnsafeUpdates = False
                                                                 End Using
                                                             End Using
                                                         End Sub)
                Catch ex As Exception
                    labelError.Text = "Can not E-mail this News Article Page" & vbCrLf & ex.Message
                    SendErrorToNetFeedback(ex)
                    ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not E-mail this News Article Page!');", True)
                End Try
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Success, Message Info", "javascript:success('Sucessfully E-mailed this News Clippings Article Page');", True)
                getNews()
            End If
        End If
    End Sub
    Sub getNews()
        labelError.Text = ""
        Try
            SPSecurity.RunWithElevatedPrivileges(Sub()
                                                     Dim web As SPWeb = Nothing
                                                     Using Site As SPSite = New SPSite(_urlPath)
                                                         web = Site.OpenWeb()
                                                         Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                         Dim query As SPQuery = New SPQuery()
                                                         If DateTimeControl1.IsDateEmpty = True And DateTimeControl2.IsDateEmpty = True And UnpublishedItems.Checked = False And Calendar1.SelectedDate.Date <> Date.MinValue Then
                                                             UnpublishedItems.Checked = False
                                                             If Not Page.IsPostBack Then
                                                                 query.Query = "<Where>" _
                                                                     & vbCr & vbLf & "<Eq>" _
                                                                     & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                     & vbCr & vbLf & "<Value Type='DateTime'><Today /></Value>" _
                                                                     & vbCr & vbLf & "</Eq>" _
                                                                     & vbCr & vbLf & "</Where>" _
                                                                     & vbCr & vbLf & "<OrderBy>" _
                                                                     & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                             Else
                                                                 query.Query = "<Where>" _
                                                                     & vbCr & vbLf & "<And>" _
                                                                     & vbCr & vbLf & "<Eq>" _
                                                                     & vbCr & vbLf & "<FieldRef Name='ContentType' />" _
                                                                     & vbCr & vbLf & "<Value Type='Computed'>NewsClippings_CT</Value>" _
                                                                     & vbCr & vbLf & "</Eq>" _
                                                                     & vbCr & vbLf & "<Eq>" _
                                                                     & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                     & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(_seldate) + "</Value>" _
                                                                     & vbCr & vbLf & "</Eq>" _
                                                                     & vbCr & vbLf & "</And>" _
                                                                     & vbCr & vbLf & "</Where>" _
                                                                     & vbCr & vbLf & "<OrderBy>" _
                                                                     & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                             End If
                                                         ElseIf DateTimeControl1.IsDateEmpty = False And DateTimeControl2.IsDateEmpty = False And UnpublishedItems.Checked = False And Calendar1.SelectedDate.Date = Date.MinValue Then
                                                             UnpublishedItems.Checked = False
                                                             query.Query = "<Where>" _
                                                         & vbCr & vbLf & "<And>" _
                                                         & vbCr & vbLf & "<And>" _
                                                         & vbCr & vbLf & "<Eq>" _
                                                         & vbCr & vbLf & "<FieldRef Name='ContentType' />" _
                                                         & vbCr & vbLf & "<Value Type='Computed'>NewsClippings_CT</Value>" _
                                                         & vbCr & vbLf & "</Eq>" _
                                                         & vbCr & vbLf & "<Geq>" _
                                                         & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                         & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(_startDate) + "</Value>" _
                                                         & vbCr & vbLf & "</Geq>" _
                                                         & vbCr & vbLf & "</And>" _
                                                         & vbCr & vbLf & "<Leq>" _
                                                         & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                         & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(_endDate) + "</Value>" _
                                                         & vbCr & vbLf & "</Leq>" _
                                                         & vbCr & vbLf & "</And>" _
                                                         & vbCr & vbLf & "</Where>" _
                                                         & vbCr & vbLf & "<OrderBy>" _
                                                         & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                         Else
                                                             query.Query = "<Where>" _
                                                             & vbCr & vbLf & "<And>" _
                                                             & vbCr & vbLf & "<Eq>" _
                                                             & vbCr & vbLf & "<FieldRef Name='ContentType' />" _
                                                             & vbCr & vbLf & "<Value Type='Computed'>NewsClippings_CT</Value>" _
                                                             & vbCr & vbLf & "</Eq>" _
                                                             & vbCr & vbLf & "<IsNull>" _
                                                             & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                             & vbCr & vbLf & "</IsNull>" _
                                                             & vbCr & vbLf & "</And>" _
                                                             & vbCr & vbLf & "</Where>" _
                                                             & vbCr & vbLf & "<OrderBy>" _
                                                             & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                         End If
                                                         query.RowLimit = 100
                                                         Dim NCItems As SPListItemCollection = lstDocs.GetItems(query)
                                                         Dim dt As DataTable
                                                         dt = NCItems.GetDataTable()
                                                         Repeater1.DataSource = dt
                                                         Repeater1.DataBind()
                                                     End Using
                                                 End Sub)
        Catch ex As Exception
            'labelError.Text = "Can't load Web page" & vbCrLf & ex.Message
            SendErrorToNetFeedback(ex)
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not Display News Article Pages!');", True)
        End Try
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        lblDate.Text = ""
        UnpublishedItems.Checked = False
        Calendar1.SelectedDates.Clear()
        _startDate = DateTimeControl1.SelectedDate
        _endDate = DateTimeControl2.SelectedDate
        _seldate = DateTime.MinValue

        If _startDate <> Nothing And EndDate <> Nothing Then
            lblDate.Text = "News Articles published between: " + _startDate.ToShortDateString().ToString() + " And " + _endDate.ToShortDateString().ToString()
            getNews()
        Else
            lblDate.Text = "You have to select date range!"
        End If
    End Sub
    Protected Sub AddClipping_Click(sender As Object, e As EventArgs) Handles AddClipping.Click
        labelError.Text = ""
        If (IsUserAuthorized(SecuritySpGroup) = True) Then
            AddArticleRow.Visible = False
            Preview.Visible = False
            AddNewsClipping.Visible = False
            CreatePages()
        End If
    End Sub
    Public Function IsUserAuthorized(ByVal groupName As String) As Boolean
        'Retreiving the current context 
        Dim site As SPSite = SPContext.Current.Site
        'Opening a current web and creating a instance 
        Dim web As SPWeb = site.OpenWeb
        'Retreiving the current logged in user  
        Dim currentUser As SPUser = web.CurrentUser
        'Retrieving all the user groups in the site/web   
        Dim userGroups As SPGroupCollection = currentUser.Groups
        'Loops through the grops and check if the user is part of given group or not. 
        For Each group As SPGroup In userGroups
            'Checking the group 
            If group.Name.Contains(groupName) Then
                Return True
            End If
        Next group
        Return False
    End Function
    Private Sub CreatePages()
        labelError.Text = ""
        Try
            SPSecurity.RunWithElevatedPrivileges(Sub()
                                                     Using Site As SPSite = New SPSite(_urlPath)
                                                         Using web As SPWeb = Site.OpenWeb()
                                                             Dim list As SPList = web.Lists("News Articles")
                                                             Dim item As SPListItem = list.Items.Add()
                                                             Dim formattedDT As String = Now.ToString("MMM/dd/yyyy")
                                                             web.AllowUnsafeUpdates = True
                                                             item("Title") = formattedDT
                                                             item("NewsArticle") = htmlTables
                                                             item("NewsArticlesTitles") = htmlTitles
                                                             item.Update()
                                                             web.AllowUnsafeUpdates = False
                                                         End Using
                                                     End Using
                                                 End Sub)

        Catch ex As Exception
            labelError.Text = "Cannot insert new page article clippings" & vbCrLf & ex.Message
            'SPDiagnosticsCategory("Add Category", TraceSeverity.Monitorable, EventSeverity.Error),EventSeverity.Monitorable,"Writing to the Event log: {0}",new object[] { "Error trying to add new record to NewsClipping_WP !"});
            SendErrorToNetFeedback(ex)
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, trying to Add Clippings!');", True)
        End Try
        ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Success, Message Info", "javascript:success('New Clippings Added Sucessfully');", True)
    End Sub
    Protected Sub UnpublishedItems_CheckedChanged(sender As Object, e As EventArgs) Handles UnpublishedItems.CheckedChanged
        If UnpublishedItems.Checked = True Then
            labelError.Text = ""
            Calendar1.SelectedDates.Clear()
            Calendar1.SelectedDate = DateTime.MinValue
            DateTimeControl1.SelectedDate = Nothing
            DateTimeControl2.SelectedDate = Nothing
            DateTimeControl1.ClearSelection()
            DateTimeControl2.ClearSelection()
            _startDate = Nothing
            _endDate = Nothing
            _seldate = Nothing
            getNews()
            lblDate.Text = "Unpublished News Articles"
        End If
    End Sub
    Protected Sub AddNewsClipping_Click(sender As Object, e As EventArgs) Handles AddNewsClipping.Click
        If (IsUserAuthorized(SecuritySpGroup) = True) Then
            MultiNewsRepeater.Visible = True
            AddArticleRow.Visible = True
            Preview.Visible = True
            DateTimeControlCT.Visible = True
        End If
    End Sub
    Protected Sub AddArticleRow_Click(sender As Object, e As EventArgs) Handles AddArticleRow.Click
        AddNewRow()
    End Sub
    Private Sub SetInitialRow()
        Dim dt1 As DataTable = New DataTable()
        Dim dr As DataRow = Nothing
        'Create DataTable columns
        dt1.Columns.Add(New DataColumn("RowNumber", GetType(String)))
        dt1.Columns.Add(New DataColumn("Title", GetType(String)))
        dt1.Columns.Add(New DataColumn("ByLine", GetType(String)))
        dt1.Columns.Add(New DataColumn("NewsSource", GetType(String)))
        ' dt1.Columns.Add(New DataColumn("SourceDate", GetType(String)))
        dt1.Columns.Add(New DataColumn("NewsStory", GetType(String)))
        'Create Row for each columns
        dr = dt1.NewRow()
        dr("RowNumber") = 1
        dr("Title") = String.Empty
        dr("ByLine") = String.Empty
        dr("NewsSource") = String.Empty
        ' dr("SourceDate") = String.Empty
        dr("NewsStory") = String.Empty
        dt1.Rows.Add(dr)
        'Store the DataTable in ViewState for future reference
        ViewState("CurrentTable") = dt1
        'Bind the Repeater with the DataTable
        MultiNewsRepeater.DataSource = dt1
        MultiNewsRepeater.DataBind()
    End Sub
    Private Sub AddNewRow()
        Dim rowIndex As Integer = 0
        If Not ViewState("CurrentTable") Is Nothing Then
            Dim dtCurrentTable As DataTable = CType(ViewState("CurrentTable"), DataTable)
            Dim drCurrentRow As DataRow = Nothing
            If dtCurrentTable.Rows.Count > 0 Then
                Dim i As Integer
                For i = 1 To dtCurrentTable.Rows.Count Step i + 1
                    'extract the TextBox values
                    Dim Title As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtTitle"), TextBox)
                    Dim ByLine As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT3"), TextBox)
                    Dim NewsSource As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT1"), TextBox)
                    'Dim SourceDate As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("lblSourcedate"), TextBox)
                    Dim NewsStory As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT2"), TextBox)
                    'Create new row in DataTable and set its values
                    drCurrentRow = dtCurrentTable.NewRow()
                    drCurrentRow("RowNumber") = i + 1
                    dtCurrentTable.Rows(i - 1)("Title") = Title.Text
                    dtCurrentTable.Rows(i - 1)("ByLine") = ByLine.Text
                    dtCurrentTable.Rows(i - 1)("NewsSource") = NewsSource.Text
                    'dtCurrentTable.Rows(i - 1)("SourceDate") = SourceDate.Text
                    dtCurrentTable.Rows(i - 1)("NewsStory") = NewsStory.Text
                    rowIndex = rowIndex + 1
                Next
                'add the new row to the current DataTable
                dtCurrentTable.Rows.Add(drCurrentRow)
                'store the current DataTable in ViewState
                ViewState("CurrentTable") = dtCurrentTable
                'rebind the Repeater with the updated DataTable
                MultiNewsRepeater.DataSource = dtCurrentTable
                MultiNewsRepeater.DataBind()
            End If
        Else
            'Response("ViewState is null")
        End If
        'Set Previous Data on Postbacks
        SetPreviousData()
    End Sub
    Private Sub SetPreviousData()
        Dim rowIndex As Integer = 0
        If Not ViewState("CurrentTable") Is Nothing Then
            Dim dt As DataTable = CType(ViewState("CurrentTable"), DataTable)
            If dt.Rows.Count > 0 Then
                Dim i As Integer
                For i = 0 To dt.Rows.Count - 1 Step i + 1
                    Dim Title As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtTitle"), TextBox)
                    Dim ByLine As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT3"), TextBox)
                    Dim NewsSource As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT1"), TextBox)
                    'Dim SourceDate As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("lblSourcedate"), TextBox)
                    Dim NewsStory As TextBox = CType(MultiNewsRepeater.Items(rowIndex).FindControl("txtCT2"), TextBox)
                    'Disable previous rows
                    If i < dt.Rows.Count - 1 Then
                        Title.Enabled = False
                        ByLine.Enabled = False
                        NewsSource.Enabled = False
                        'SourceDate.Enabled = False
                        NewsStory.Enabled = False
                    Else
                        Title.Enabled = True
                        ByLine.Enabled = True
                        NewsSource.Enabled = True
                        'SourceDate.Enabled = True
                        NewsStory.Enabled = True
                    End If
                    Title.Text = dt.Rows(i)("Title").ToString()
                    ByLine.Text = dt.Rows(i)("ByLine").ToString()
                    NewsSource.Text = dt.Rows(i)("NewsSource").ToString()
                    'SourceDate.Text = dt.Rows(i)("SourceDate").ToString()
                    NewsStory.Text = dt.Rows(i)("NewsStory").ToString()
                    rowIndex = rowIndex + 1
                Next
            End If
        End If
    End Sub
    Protected Sub Preview_Click(sender As Object, e As EventArgs) Handles Preview.Click
        '//Create Table
        htmlTables = ""
        htmlTitles = ""
        If Not ViewState("CurrentTable") Is Nothing Then
            Dim dtCurrentTable As DataTable = CType(ViewState("CurrentTable"), DataTable)
            If dtCurrentTable.Rows.Count > 1 Then
                Dim i As Integer
                Dim Article As String
                For i = 0 To dtCurrentTable.Rows.Count - 1
                    'extract the TextBox values
                    If dtCurrentTable.Rows(i)("NewsStory").ToString().Length >= 150 Then
                        Article = dtCurrentTable.Rows(i)("NewsStory").ToString().Substring(0, 150) + ". . ."
                    Else
                        Article = dtCurrentTable.Rows(i)("NewsStory").ToString() + ". . ."
                    End If
                    Dim r As TableRow = New TableRow()
                    r.Attributes.Add("ID", i.ToString())
                    Dim c As TableCell = New TableCell()
                    c.Controls.Add(New LiteralControl("<b><A href='#" + i.ToString() + "'>" + dtCurrentTable.Rows(i)("Title").ToString() + "</A></b>&nbsp;" + Article))
                    r.Cells.Add(c)
                    oTableHeader.Rows.Add(r)
                    Dim r1 As TableRow = New TableRow()
                    r1.Attributes.Add("ID", i.ToString())
                    Dim c1 As TableCell = New TableCell()
                    c1.Controls.Add(New LiteralControl("<A name='" + i.ToString() + "'></A>" + "<b>" + dtCurrentTable.Rows(i)("Title").ToString() + "</b><br>" + dtCurrentTable.Rows(i)("NewsSource").ToString() + "<br>" + DateTimeControlCT.SelectedDate.ToString("MMM/dd/yyyy") + "<br>" + dtCurrentTable.Rows(i)("ByLine").ToString() + "<br>" + dtCurrentTable.Rows(i)("NewsStory").ToString() + "<br>" + "<A class=NewsSubhead href='#top'>Return to Top</A>"))
                    r1.Cells.Add(c1)
                    oTable1.Rows.Add(r1)
                    htmlTitles += dtCurrentTable.Rows(i)("Title").ToString() + "<br />"
                Next
            End If
            Dim rn As Integer
            rn = Convert.ToInt32(oTable1.Rows.Count)
            oTableHeader.Rows.RemoveAt(rn - 1)
            oTable1.Rows.RemoveAt(rn - 1)
            Dim sb As StringBuilder = New StringBuilder()
            NC_HtmlGeneration.RenderControl(New HtmlTextWriter(New StringWriter(sb)))
            Dim s As String = sb.ToString()
            htmlTables = s
        End If
        AddClipping.Visible = True
        MultiNewsRepeater.Visible = False
        AddArticleRow.Visible = False
        DateTimeControlCT.Visible = False
        Preview.Visible = False
    End Sub
    Public Sub SendErrorToNetFeedback(ByVal ex As Exception)
        Try
            Dim Smtp_Server As New SmtpClient
            Dim e_mail As New MailMessage()
            Smtp_Server.UseDefaultCredentials = True
            Smtp_Server.Port = 25
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = _SmptServerName
            e_mail = New MailMessage()
            e_mail.From = New MailAddress("netfeedback@mpi.mb.ca")
            e_mail.To.Add("arazic@mpi.mb.ca")
            e_mail.Subject = "ERROR - News Clipping"
            e_mail.IsBodyHtml = True
            e_mail.Body = "<font face=verdana size=4 color=red>Error at: </font><br />"
            e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Target Site:</font><br />"
            e_mail.Body += "<font face=verdana size=2>" & ex.TargetSite.ToString & "</font>"
            e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Exception Messages:</font><br />"
            e_mail.Body += "<font face=verdana size=2>" & ex.Message & "</font>"
            e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Source Error:</font><br />"
            e_mail.Body += "<font face=verdana size=2>" & ex.Source.ToString & "</font>"
            e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Server Error:</font><br />"
            e_mail.Body += "<font face=verdana size=2>" & ex.ToString() & "</font>"
            e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Stack Trace:</font><br />"
            e_mail.Body += "<font face=verdana size=2>" & ex.StackTrace.ToString() & "</font>"
            If Not IsNothing(ex.InnerException) Then
                e_mail.Body += "<br /><br /><font face=verdana size=4 color=red>Inner Exception:</font><br />"
                e_mail.Body += "<font face=verdana size=2>" & ex.InnerException.ToString() & "</font>"
            End If
            ServicePointManager.ServerCertificateValidationCallback = _
            New System.Net.Security.RemoteCertificateValidationCallback(AddressOf customCertValidation)
            Smtp_Server.Send(e_mail)
        Catch ex2 As Exception
            'Ignore since we don't want the user to see an ugly error
            'Throw ex
        Finally
            'nothing
        End Try
    End Sub
    Private Shared Function customCertValidation(ByVal sender As Object, _
                                                        ByVal cert As X509Certificate, _
                                                        ByVal chain As X509Chain, _
                                                        ByVal errors As SslPolicyErrors) As Boolean
        Return True
    End Function

    Private Function GetFirstDayOfMonth(ByVal iMonth As Int32) As DateTime
        Dim dtFrom As New DateTime(DateTime.Now.Year, iMonth, 1)
        dtFrom = dtFrom.AddDays(-(dtFrom.Day - 1))
        Return dtFrom
    End Function
    Private Function GetLastDayOfMonth(ByVal iMonth As Int32) As DateTime
        Dim dtTo As New DateTime(DateTime.Now.Year, iMonth, 1)
        dtTo = dtTo.AddMonths(1)
        dtTo = dtTo.AddDays(-(dtTo.Day))
        Return dtTo
    End Function

    Sub Calendar1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs)
        Try
            SPSecurity.RunWithElevatedPrivileges(Sub()
                                                     Using Site As SPSite = New SPSite(_urlPath)
                                                         Using web As SPWeb = Site.OpenWeb()
                                                             Dim Image1 As Image = New Image()
                                                             Image1.ImageUrl = "~/Style Library/NewsClippingsImages/NewsClippingsImages/pin.png"

                                                             Dim lstDocs1 As SPList = SPContext.Current.Web.Lists.TryGetList("News Articles")
                                                             Dim query As SPQuery = New SPQuery()
                                                             If Page.IsPostBack Then
                                                                 If DDLMonth.SelectedIndex + 1 = 0 Then
                                                                     DDLMonth_SelectedIndexChanged(Nothing, Nothing)
                                                                     DDLYear_SelectedIndexChanged(Nothing, Nothing)
                                                                 End If
                                                                 Dim strdt As String = (DDLMonth.SelectedIndex + 1 & "/1/" & DDLYear.SelectedValue).ToString()

                                                                 Dim FirstSelectedDate As Date = CDate(strdt)
                                                                 Dim LastSelectedDate As Date = FirstSelectedDate.AddMonths(1).AddDays(-1)
                                                                 query.Query = "<Where>" _
                                                                & vbCr & vbLf & "<And>" _
                                                                & vbCr & vbLf & "<And>" _
                                                                & vbCr & vbLf & "<Eq>" _
                                                                & vbCr & vbLf & "<FieldRef Name='ContentType' />" _
                                                                & vbCr & vbLf & "<Value Type='Computed'>NewsClippings_CT</Value>" _
                                                                & vbCr & vbLf & "</Eq>" _
                                                                & vbCr & vbLf & "<Geq>" _
                                                                & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(FirstSelectedDate) + "</Value>" _
                                                                & vbCr & vbLf & "</Geq>" _
                                                                & vbCr & vbLf & "</And>" _
                                                                & vbCr & vbLf & "<Leq>" _
                                                                & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(LastSelectedDate) + "</Value>" _
                                                                & vbCr & vbLf & "</Leq>" _
                                                                & vbCr & vbLf & "</And>" _
                                                                & vbCr & vbLf & "</Where>" _
                                                                & vbCr & vbLf & "<OrderBy>" _
                                                                & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                             ElseIf Not Page.IsPostBack Then
                                                                 query.Query = "<Where>" _
                                                                 & vbCr & vbLf & "<And>" _
                                                                 & vbCr & vbLf & "<And>" _
                                                                 & vbCr & vbLf & "<Eq>" _
                                                                 & vbCr & vbLf & "<FieldRef Name='ContentType' />" _
                                                                 & vbCr & vbLf & "<Value Type='Computed'>NewsClippings_CT</Value>" _
                                                                 & vbCr & vbLf & "</Eq>" _
                                                                 & vbCr & vbLf & "<Geq>" _
                                                                 & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                 & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(GetFirstDayOfMonth(DateTime.Now.Month)) + "</Value>" _
                                                                 & vbCr & vbLf & "</Geq>" _
                                                                 & vbCr & vbLf & "</And>" _
                                                                 & vbCr & vbLf & "<Leq>" _
                                                                 & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' />" _
                                                                 & vbCr & vbLf & "<Value IncludeTimeValue='FALSE'  Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(GetLastDayOfMonth(DateTime.Now.Month)) + "</Value>" _
                                                                 & vbCr & vbLf & "</Leq>" _
                                                                 & vbCr & vbLf & "</And>" _
                                                                 & vbCr & vbLf & "</Where>" _
                                                                 & vbCr & vbLf & "<OrderBy>" _
                                                                 & vbCr & vbLf & "<FieldRef Name='ArticlePublishingDate' Ascending='False'/></Order By>"
                                                             End If
                                                             Dim NCItems1 As SPListItemCollection = lstDocs1.GetItems(query)

                                                             ' Dim dt1 As DataTable
                                                             ' dt1 = NCItems1.GetDataTable()

                                                             Dim item As SPListItem
                                                             For Each item In NCItems1
                                                                 If e.Day.Date.Equals(CType(item.Item("ArticlePublishingDate").ToString, DateTime).Date) Then
                                                                     'e.Cell.ToolTip = item("NewsArticlesTitles").ToString()
                                                                     e.Cell.CssClass = "NC_Calendar1_DayStyle"
                                                                     e.Cell.BorderColor = Drawing.Color.White
                                                                     e.Cell.BorderStyle = UI.WebControls.BorderStyle.Solid
                                                                     e.Cell.BorderWidth = 1
                                                                     e.Cell.ForeColor = Drawing.Color.White
                                                                     e.Day.IsSelectable = True
                                                                     e.Cell.Controls.AddAt(0, Image1)
                                                                 End If
                                                             Next item
                                                             If e.Day.IsOtherMonth = True Then
                                                                 e.Cell.Text = ""
                                                             End If
                                                         End Using
                                                     End Using
                                                 End Sub)
        Catch ex As Exception
            If ex.Message = "String was not recognized as a valid DateTime." Then
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Something went wrong, Please Try Again!');", True)
            Else
                labelError.Text = "Can't load Web page" & vbCrLf & ex.Message
                'SendErrorToNetFeedback(ex)
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Something went wrong, Please Try Again!');", True)
            End If
        End Try
    End Sub
    Protected Sub DDLMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLMonth.SelectedIndexChanged
        SetCalendar()
    End Sub
    Protected Sub DDLYear_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLYear.SelectedIndexChanged
        SetCalendar()
    End Sub
    Private Sub LoadNavigation()
        Me.DDLMonth.Items.Clear()
        Me.DDLYear.Items.Clear()
        Try
            Dim intCtr As Int16
            Dim strDate As String
            ' Add the Months to the DropDownList
            For intCtr = 1 To 12
                strDate = intCtr & "/13/" & Now.Year
                Me.DDLMonth.Items.Add(Format(CDate(strDate), "MMMM"))
            Next
            ' Add the Years to the DropDownList
            For intCtr = 2003 To Now.Year
                Me.DDLYear.Items.Add(intCtr)
            Next
            Me.DDLMonth.SelectedIndex = Now.Month - 1
            Me.DDLYear.SelectedValue = Now.Year
        Catch ex As Exception
        End Try
    End Sub
    Private Sub SetCalendar()
        Try
            Dim strDate As String
            strDate = (DDLMonth.SelectedIndex + 1 & "/1/" & DDLYear.SelectedValue).ToString()
            Calendar1.VisibleDate = CDate(strDate)
        Catch ex As Exception
            SendErrorToNetFeedback(ex)
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Something went wrong, please, try again!');", True)

        End Try
    End Sub

    Protected Sub CB_EmailSubscriber_CheckedChanged(sender As Object, e As EventArgs) Handles CB_EmailSubscriber.CheckedChanged
        If Page.IsPostBack Then
            Try
                SPSecurity.RunWithElevatedPrivileges(Sub()
                                                         'Check if current user is member of Distribution List
                                                         Using Site2 As SPSite = New SPSite(_urlPath)
                                                             'Opening a current web and creating a instance 
                                                             Using web2 As SPWeb = Site2.OpenWeb()
                                                                 'Retreiving the current logged in user  
                                                                 Dim currentUser As SPUser = web2.CurrentUser
                                                                 Dim Cuser As String = currentUser.Email.ToString

                                                                 If Cuser = Nothing Then
                                                                     Cuser = "arazic@mpi.mb.ca"
                                                                     'Exit Sub
                                                                 End If
                                                                 Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("NC Distribution List")
                                                                 Dim ls As SPListItemCollection = lstDocs.Items

                                                                 Dim count As Integer = ls.List.Items.Count
                                                                 If count > 0 Then
                                                                     Dim DLitem As SPListItem

                                                                     For Each DLitem In ls
                                                                         If CB_EmailSubscriber.Checked = False Then
                                                                             If DLitem("Title").ToString() = Cuser Then
                                                                                 web2.AllowUnsafeUpdates = True
                                                                                 DLitem.Delete()
                                                                                 web2.AllowUnsafeUpdates = False
                                                                                 LblEmailSubscriber.Text = "You have unsubscribed from email distribution list."
                                                                                 Exit For
                                                                             End If
                                                                         End If
                                                                     Next DLitem
                                                                     If CB_EmailSubscriber.Checked = True Then
                                                                         web2.AllowUnsafeUpdates = True
                                                                         Dim NewDLitem As SPListItem = lstDocs.Items.Add()
                                                                         NewDLitem("Title") = Cuser
                                                                         NewDLitem.Update()
                                                                         web2.AllowUnsafeUpdates = False
                                                                         LblEmailSubscriber.Text = "Thank you " + currentUser.Name + ", for adding me to email subscription."
                                                                     End If

                                                                 End If
                                                             End Using
                                                         End Using
                                                     End Sub)
            Catch ex As Exception
                labelError.Text = "Can't load Web page" & vbCrLf & ex.Message
                SendErrorToNetFeedback(ex)
                ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Can not Display News Article Pages!');", True)
            End Try
        End If
    End Sub

    Private Sub DistributionList()
        Try
            SPSecurity.RunWithElevatedPrivileges(Sub()
                                                     'Check if current user is member of Distribution List
                                                     Using Site1 As SPSite = New SPSite(_urlPath)
                                                         'Opening a current web and creating a instance 
                                                         Using web1 As SPWeb = Site1.OpenWeb()
                                                             'Retreiving the current logged in user  
                                                             Dim currentUser As SPUser = web1.CurrentUser
                                                             Dim Cuser As String = currentUser.Email.ToString
                                                             If Cuser = Nothing Then
                                                                 Cuser = "arazic@mpi.mb.ca"
                                                             End If
                                                             Dim lstDocs As SPList = SPContext.Current.Web.Lists.TryGetList("NC Distribution List")
                                                             Dim ls As SPListItemCollection = lstDocs.Items
                                                             Dim count As Integer = ls.List.Items.Count
                                                             If count > 0 Then
                                                                 Dim DLitem As SPListItem
                                                                 For Each DLitem In ls
                                                                     If DLitem("Title").ToString() = Cuser Then
                                                                         LblEmailSubscriber.Text = "Welcome " + currentUser.Name + ", uncheck box to unsubscribe if you do not want to receive News Clipping Emails anymore."
                                                                         CB_EmailSubscriber.Checked = True
                                                                         Exit For
                                                                     ElseIf DLitem("Title").ToString() <> Cuser Then
                                                                         LblEmailSubscriber.Text = "Welcome " + currentUser.Name + ", check box to subscribe for News Clipping Emails."
                                                                     End If
                                                                 Next DLitem
                                                             End If
                                                         End Using
                                                     End Using
                                                 End Sub)
        Catch ex As Exception
            'labelError.Text = "Can't load Web page" & vbCrLf & ex.Message
            SendErrorToNetFeedback(ex)
            ScriptManager.RegisterStartupScript(UpdatePanel1, UpdatePanel1.GetType(), "Error, Message Info", "javascript:success('Error, Cannot check/uncheck e-mail subscription!');", True)
        End Try
        'If yes display message welcome user, Do you want to Un-subscribe from news clippings
        'In no display message welcome user, Chek to subscribe for Email News Clippings
        'If checked update distribution list and make check box read only for anyone but the user.
    End Sub

   
End Class