# Setup the correct modules for SharePoint Manipulation 
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null ) 
{ 
   Add-PsSnapin Microsoft.SharePoint.PowerShell 
} 
$host.Runspace.ThreadOptions = "ReuseThread" 

#Open SharePoint List 
$SPServer="http://kndev-stage"
$SPAppList="/Lists/News%20Articles/" 
$spWeb = Get-SPWeb $SPServer 
$spData = $spWeb.GetList($SPAppList) 
$items = $spData.items
#Delete Items From SP list 
foreach ($item in $items)
{
    Write-host "  Say Goodbye to $($item.id)" -foregroundcolor red
    $spData.getitembyid($Item.id).Delete()
}


######connect to SQL database windows authentication ###########

$connection= new-object system.data.sqlclient.sqlconnection #Set new object to connect to sql database 

$Connection.ConnectionString ="server=SP2013DEVSERVER;database=NewsClippings;trusted_connection=true" # Connectiongstring setting for <ServerName> <databasename> with window authentication

#$Connection.ConnectionString ="server=<ServerName>;database=<databasename>;User Id=<username>;Password=<password>;trusted_connection=False; # Connectiongstring setting for <ServerName> <databasename> with SQL authentication <username><password>

Write-host "connection information:" 

$connection #List connection information 

Write-host "Connecting to database.." 

$connection.open() #Open Connection


######### SQL query #############

$SqlCmd = New-Object System.Data.SqlClient.SqlCommand #setting object to use sql commands 

$SqlQuery = "SELECT [NEWS_ITM_ENTRY_DT],[Clipping_HTML] FROM [NC] " #set SQL query 

$SqlCmd.CommandText = $SqlQuery # get query 

$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter # 

$SqlAdapter.SelectCommand = $SqlCmd # 

$SqlCmd.Connection = $connection 

$DataSet = New-Object System.Data.DataSet 

$SqlAdapter.Fill($DataSet) 

$SqlAdapter.Dispose()

$connection.Close() 

$DataSet.Tables[0]

######### Add to SPList ########

$spWeb = Get-SPWeb -identity "http://kndev-stage/"  #  Get SPWeb 

$list = $spWeb.Lists["News Articles"]


Write-host "Writing  to list ..." 

foreach ($Row in $DataSet.Tables[0].Rows)
{ 

$item = $list.Items.Add();

$item["Title"] = $Row["NEWS_ITM_ENTRY_DT"].ToShortDateString()
$item["News Articles Titles"] = $Row["Headline_HTML"]
$item["News Article"] = $Row["Clipping_HTML"]
$item["Article Publishing Date"] = $Row["NEWS_ITM_ENTRY_DT"]
$item["Publishing Checker"] = 1
$item["Mail Sent"] = 1
$item.Update()
}
Write-host "Done!." 
$spWeb.Dispose()