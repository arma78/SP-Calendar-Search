﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

''' <summary>
''' This class contains the properties for Entity1. The properties keep the data for Entity1.
''' If you want to rename the class, don't forget to rename the entity in the model xml as well.
''' </summary>
Partial Public Class Entity1
    Private _identifier1 As String
    Private _message As String

    'TODO: Implement additional properties here. The property Message is just a sample how a property could look like.
    Public Property Identifier1() As String
        Get
            Return _identifier1
        End Get
        Set(ByVal value As String)
            _identifier1 = value
        End Set
    End Property

    Public Property Message() As String
        Get
            Return _message
        End Get
        Set(ByVal value As String)
            _message = value
        End Set
    End Property
End Class
