﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

''' <summary>
''' All the methods for retrieving, updating and deleting data are implemented in this class file.
''' The samples below show the finder and specific finder method for Entity1.
''' </summary>
Public Class Entity1Service
    ''' <summary>
    ''' This is a sample specific finder method for Entity1.
    ''' If you want to delete or rename the method think about changing the xml in the BDC model file as well.
    ''' </summary>
    ''' <param name="id"></param>
    ''' <returns>Entity1</returns>
    Public Shared Function ReadItem(ByVal id As String) As Entity1
        'TODO: This is just a sample. Replace this simple sample with valid code.
        Dim entity1 As New Entity1()
        entity1.Identifier1 = id
        entity1.Message = "Hello World"
        Return entity1
    End Function

    ''' <summary>
    ''' This is a sample finder method for Entity1.
    ''' If you want to delete or rename the method think about changing the xml in the BDC model file as well.
    ''' </summary>
    ''' <returns>IEnumerable of Entities</returns>
    Public Shared Function ReadList() As IEnumerable(Of Entity1)
        'TODO: This is just a sample. Replace this simple sample with valid code.
        Dim entity1 As New Entity1()
        entity1.Identifier1 = "0"
        entity1.Message = "Hello World"
        Dim myEntityList As Entity1() = {entity1}
        Return myEntityList
    End Function
End Class
