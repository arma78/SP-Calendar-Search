Imports System
Imports System.Runtime.InteropServices
Imports System.Security.Permissions
Imports Microsoft.SharePoint
Imports System.Collections.Generic
Imports Microsoft.SharePoint.Administration
Imports Microsoft.SharePoint.WebControls
Imports Microsoft.SharePoint.Linq
Imports System.Security.Policy
Imports CodeLibrary
''' <summary>
''' This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
''' </summary>
''' <remarks>
''' The GUID attached to this class may be used during packaging and should not be modified.
''' </remarks>

<GuidAttribute("cc90705c-e40b-474f-bae7-277ad369afb7")> _
Public Class NewsClippingsContentEventReceiver
    Inherits SPFeatureReceiver

    ' Uncomment the method below to handle the event raised after a feature has been activated.

    Public Overrides Sub FeatureActivated(ByVal properties As SPFeatureReceiverProperties)
        Dim site As SPSite = properties.Feature.Parent
        Dim tc As ProvisionDisplayTemplate
        tc = New ProvisionDisplayTemplate
        tc.DisplayTemplate(site)
    End Sub
   




    ' Uncomment the method below to handle the event raised before a feature is deactivated.

    'Public Overrides Sub FeatureDeactivating(ByVal properties As SPFeatureReceiverProperties)
    'End Sub


    ' Uncomment the method below to handle the event raised after a feature has been installed.

    'Public Overrides Sub FeatureInstalled(ByVal properties As SPFeatureReceiverProperties)
    'End Sub


    ' Uncomment the method below to handle the event raised before a feature is uninstalled.

    'Public Overrides Sub FeatureUninstalling(ByVal properties As SPFeatureReceiverProperties)
    'End Sub

    ' Uncomment the method below to handle the event raised when a feature is upgrading.

    'Public Overrides Sub FeatureUpgrading(ByVal properties As Microsoft.SharePoint.SPFeatureReceiverProperties, ByVal upgradeActionName As String, ByVal parameters As System.Collections.Generic.IDictionary(Of String, String))
    'End Sub

End Class
