﻿function GetRowNumber() {
    var noRows = document.getElementById('ctl00_ctl39_g_ffd65b01_343e_4804_a24a_3fa276640ce0_oTable1').rows.length;
    var options = {
        url: '/_layouts/15/MPI.KMS.NewsClippingContent/ClippingPopUp.aspx',
        width: 260,
        height: 200,
        args: noRows,
        title: "News Articles Removal",
        dialogReturnValueCallback: SubmitDataCallback,
        allowMaximize: false,
        showClose: true
    };
    SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);
}

// Custom callback function after the dialog is closed 
function SubmitDataCallback(dialogResult, returnValue) {

    if (dialogResult == SP.UI.DialogResult.OK)
    {
        
        var d = document.getElementById('ctl00_ctl39_g_ffd65b01_343e_4804_a24a_3fa276640ce0_oTable1').deleteRow(returnValue);
        var h = document.getElementById('ctl00_ctl39_g_ffd65b01_343e_4804_a24a_3fa276640ce0_oTableHeader').deleteRow(returnValue);
        SP.UI.ModalDialog.commonModalDialogClose(SP.UI.DialogResult.OK);
        SP.UI.Notify.addNotification("You heve removed news article. Please click save button to update News Clipping", true, "Dialog response",null);
    }

    if (dialogResult == SP.UI.DialogResult.cancel) {


        SP.UI.Notify.addNotification("You cancled operation!", false, "", null);

    }
}

function bindDdl() {
    document.getElementById("NewsArticleClippDDl").options.length = 0;
    var noNews = window.frameElement.dialogArgs;

    var x = [noNews];
    var sel = document.getElementById('NewsArticleClippDDl');

    for (var i = 0; i <= x - 1 ; i++) {
        var c = "News Article #: " + (i + 1);
        var opt = document.createElement('option');
        opt.innerHTML = c;
        opt.value = i;
        sel.appendChild(opt);
    }

}

