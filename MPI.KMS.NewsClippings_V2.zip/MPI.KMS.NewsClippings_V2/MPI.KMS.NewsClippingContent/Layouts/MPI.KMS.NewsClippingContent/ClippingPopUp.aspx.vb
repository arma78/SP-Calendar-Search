﻿Imports System
Imports Microsoft.SharePoint
Imports Microsoft.SharePoint.WebControls
Namespace Layouts.MPI.KMS.NewsClippingContent
    Partial Public Class ClippingPopUp
        Inherits LayoutsPageBase
        Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "NC_RemoveRow", "<SCRIPT LANGUAGE='JavaScript' src='/_layouts/15/MPI.KMS.NewsClippingContent/NC_RemoveRow.js'></script>")

            'Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "ddlbox", "bindDdl();", True)
        End Sub
    End Class
End Namespace
