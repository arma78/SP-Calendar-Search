﻿#-------------------------------------------------------------------- 
# Name: Load CSV into SharePoint List 
#--------------------------------------------------------------------



# Setup the correct modules for SharePoint Manipulation 
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null ) 
{ 
   Add-PsSnapin Microsoft.SharePoint.PowerShell 
} 
$host.Runspace.ThreadOptions = "ReuseThread" 

#Open SharePoint List 
$SPServer="http://kndev-stage"
$SPAppList="/Lists/News%20Articles/" 
$spWeb = Get-SPWeb $SPServer 
$spData = $spWeb.GetList($SPAppList) 


$items = $spData.items
foreach ($item in $items)
{
    Write-host "  Say Goodbye to $($item.id)" -foregroundcolor red
    $spData.getitembyid($Item.id).Delete()
}



$InvFile="NewsClippingsFormatted.csv" 
# Get Data from Excell CSV File 
$FileExists = (Test-Path $InvFile -PathType Leaf) 
if ($FileExists) { 
   "Loading $InvFile for processing..." 
   $tblData = Import-CSV $InvFile 
} else { 
   "$InvFile not found - stopping import!" 
   exit 
} 

# Loop through Applications add each one to SharePoint 


"Uploading data to SharePoint...." 

foreach ($row in $tblData) 
{ 
 
   $spItem = $spData.AddItem() 
   $spItem["Title"] = $row."NEWS_ITM_ENTRY_DT".ToString() 
   $spItem["News Articles Titles"] = $row."FormattedHeader"
   $spItem["News Article"] = $row."Clipping".ToString() 
   $spItem["Article Publishing Date"] = $row."NEWS_ITM_ENTRY_DT".
   $spItem["Publishing Checker"] = $row."Published" 
   $spItem.Update() 
} 

"---------------" 
"Upload Complete" 

$spWeb.Dispose()
